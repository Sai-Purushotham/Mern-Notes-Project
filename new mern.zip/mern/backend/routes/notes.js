const express = require('express');
const {
  getNotes,
  getNote,
  createNote,
  updateNote,
  deleteNote,
  getTags,
  bulkOperations,
  searchNotes
} = require('../controllers/notesController');

const protect  = require('../middleware/auth');
const {
  validateNoteCreation,
  validateNoteUpdate
} = require('../middleware/validation');

const router = express.Router();

// Apply authentication to all routes
router.use(protect);

// @desc    Get all notes & Create new note
// @route   GET/POST /api/notes
// @access  Private
router.route('/')
  .get(getNotes)
  .post(validateNoteCreation, createNote);

// @desc    Search notes
// @route   GET /api/notes/search
// @access  Private
router.get('/search', searchNotes);

// @desc    Get user tags
// @route   GET /api/notes/tags
// @access  Private
router.get('/tags', getTags);

// @desc    Bulk operations on notes
// @route   POST /api/notes/bulk
// @access  Private
router.post('/bulk', bulkOperations);

// @desc    Get, Update & Delete specific note
// @route   GET/PUT/DELETE /api/notes/:id
// @access  Private
router.route('/:id')
  .get(getNote)
  .put(validateNoteUpdate, updateNote)
  .delete(deleteNote);

module.exports = router;
