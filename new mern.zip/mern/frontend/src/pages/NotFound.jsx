import React from 'react'
import { Link } from 'react-router-dom'
import { Home, ArrowLeft, Search, StickyNote } from 'lucide-react'

const NotFound = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="max-w-md w-full text-center">
        {/* 404 Illustration */}
        <div className="mb-8">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-primary-100 rounded-full mb-4">
            <StickyNote size={48} className="text-primary-600" />
          </div>
          <h1 className="text-6xl font-bold text-gray-900 mb-4">404</h1>
        </div>

        {/* Error Message */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Page Not Found
          </h2>
          <p className="text-gray-600 leading-relaxed">
            Sorry, we couldn't find the page you're looking for. The page might have been moved, deleted, or you may have entered the wrong URL.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="space-y-4">
          <Link to="/dashboard" className="btn-primary w-full flex items-center justify-center space-x-2">
            <Home size={18} />
            <span>Go to Dashboard</span>
          </Link>

          <button onClick={() => window.history.back()} className="btn-secondary w-full flex items-center justify-center space-x-2">
            <ArrowLeft size={18} />
            <span>Go Back</span>
          </button>
        </div>

        {/* Help Links */}
        <div className="mt-8 pt-8 border-t border-gray-200">
          <p className="text-sm text-gray-500 mb-4">
            Need help? Here are some useful links:
          </p>

          <div className="space-y-2">
            <Link to="/dashboard" className="block text-sm text-primary-600 hover:text-primary-700 transition-colors">
              View all notes
            </Link>
            <Link to="/notes/new" className="block text-sm text-primary-600 hover:text-primary-700 transition-colors">
              Create a new note
            </Link>
            <Link to="/profile" className="block text-sm text-primary-600 hover:text-primary-700 transition-colors">
              Account settings
            </Link>
          </div>
        </div>

        {/* Search Section */}
        <div className="mt-8 p-4 bg-white rounded-lg border border-gray-200">
          <div className="flex items-center space-x-2 mb-3">
            <Search size={16} className="text-gray-400" />
            <span className="text-sm font-medium text-gray-700">
              Looking for something specific?
            </span>
          </div>
          <p className="text-xs text-gray-500">
            Try using the search bar in the header to find your notes.
          </p>
        </div>

        {/* Footer */}
        <div className="mt-8 text-xs text-gray-400">
          <p>Error Code: 404 | Page Not Found</p>
        </div>
      </div>
    </div>
  )
}

export default NotFound
