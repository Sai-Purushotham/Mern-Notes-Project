import React, { createContext, useContext, useReducer, useCallback } from 'react'
import { notesAPI } from '../services/api'
import toast from 'react-hot-toast'

const initialState = {
  notes: [],
  currentNote: null,
  tags: [],
  loading: false,
  error: null,
  pagination: {
    currentPage: 1,
    totalPages: 1,
    totalNotes: 0,
    hasNextPage: false,
    hasPrevPage: false,
  },
  filters: {
    search: '',
    tags: [],
    sortBy: 'createdAt',
    sortOrder: 'desc',
    archived: false,
    pinned: null,
  },
}

const NotesActionTypes = {
  NOTES_START: 'NOTES_START',
  NOTES_SUCCESS: 'NOTES_SUCCESS',
  NOTES_FAIL: 'NOTES_FAIL',
  SET_CURRENT_NOTE: 'SET_CURRENT_NOTE',
  ADD_NOTE: 'ADD_NOTE',
  UPDATE_NOTE: 'UPDATE_NOTE',
  DELETE_NOTE: 'DELETE_NOTE',
  BULK_UPDATE_NOTES: 'BULK_UPDATE_NOTES',
  SET_TAGS: 'SET_TAGS',
  SET_FILTERS: 'SET_FILTERS',
  SET_PAGINATION: 'SET_PAGINATION',
  CLEAR_ERROR: 'CLEAR_ERROR',
  RESET_NOTES: 'RESET_NOTES',
}

const notesReducer = (state, action) => {
  switch (action.type) {
    case NotesActionTypes.NOTES_START:
      return { ...state, loading: true, error: null }
    case NotesActionTypes.NOTES_SUCCESS:
      return { ...state, loading: false, notes: action.payload.notes, pagination: action.payload.pagination || state.pagination, error: null }
    case NotesActionTypes.NOTES_FAIL:
      return { ...state, loading: false, error: action.payload }
    case NotesActionTypes.SET_CURRENT_NOTE:
      return { ...state, currentNote: action.payload }
    case NotesActionTypes.ADD_NOTE:
      return { ...state, notes: [action.payload, ...state.notes], pagination: { ...state.pagination, totalNotes: state.pagination.totalNotes + 1 } }
    case NotesActionTypes.UPDATE_NOTE:
      return {
        ...state,
        notes: state.notes.map(note =>
          note._id === action.payload._id ? action.payload : note),
        currentNote: state.currentNote?._id === action.payload._id ? action.payload : state.currentNote,
      }
    case NotesActionTypes.DELETE_NOTE:
      return {
        ...state,
        notes: state.notes.filter(note => note._id !== action.payload),
        currentNote: state.currentNote?._id === action.payload ? null : state.currentNote,
        pagination: { ...state.pagination, totalNotes: Math.max(0, state.pagination.totalNotes - 1) },
      }
    case NotesActionTypes.BULK_UPDATE_NOTES:
      const updatedNotes = state.notes.map(note => {
        if (action.payload.noteIds.includes(note._id)) {
          return { ...note, ...action.payload.updates }
        }
        return note
      })
      return {
        ...state,
        notes: action.payload.operation === 'delete'
          ? state.notes.filter(note => !action.payload.noteIds.includes(note._id))
          : updatedNotes,
        pagination: action.payload.operation === 'delete'
          ? { ...state.pagination, totalNotes: Math.max(0, state.pagination.totalNotes - action.payload.noteIds.length) }
          : state.pagination,
      }
    case NotesActionTypes.SET_TAGS:
      return { ...state, tags: action.payload }
    case NotesActionTypes.SET_FILTERS:
      return { ...state, filters: { ...state.filters, ...action.payload } }
    case NotesActionTypes.SET_PAGINATION:
      return { ...state, pagination: { ...state.pagination, ...action.payload } }
    case NotesActionTypes.CLEAR_ERROR:
      return { ...state, error: null }
    case NotesActionTypes.RESET_NOTES:
      return initialState
    default: return state
  }
}

const NotesContext = createContext()

export const NotesProvider = ({ children }) => {
  const [state, dispatch] = useReducer(notesReducer, initialState)

  const fetchNotes = useCallback(async (params = {}) => {
    try {
      dispatch({ type: NotesActionTypes.NOTES_START })
      const queryParams = { ...state.filters, ...params }
      const response = await notesAPI.getNotes(queryParams)
      dispatch({
        type: NotesActionTypes.NOTES_SUCCESS,
        payload: {
          notes: response.data.notes,
          pagination: {
            currentPage: response.data.currentPage,
            totalPages: response.data.totalPages,
            totalNotes: response.data.totalNotes,
            hasNextPage: response.data.currentPage < response.data.totalPages,
            hasPrevPage: response.data.currentPage > 1,
          },
        },
      })
      return response.data
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to fetch notes'
      dispatch({ type: NotesActionTypes.NOTES_FAIL, payload: errorMessage })
      toast.error(errorMessage)
      throw error
    }
  }, [state.filters])

  const fetchNote = async (noteId) => {
    try {
      const response = await notesAPI.getNote(noteId)
      dispatch({ type: NotesActionTypes.SET_CURRENT_NOTE, payload: response.data.note })
      return response.data.note
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to fetch note'
      toast.error(errorMessage)
      throw error
    }
  }

  const createNote = async (noteData) => {
    try {
      const response = await notesAPI.createNote(noteData)
      dispatch({ type: NotesActionTypes.ADD_NOTE, payload: response.data.note })
      toast.success(response.data.message || 'Note created successfully!')
      return response.data.note
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to create note'
      toast.error(errorMessage)
      throw error
    }
  }

  const updateNote = async (noteId, noteData) => {
    try {
      const response = await notesAPI.updateNote(noteId, noteData)
      dispatch({ type: NotesActionTypes.UPDATE_NOTE, payload: response.data.note })
      toast.success(response.data.message || 'Note updated successfully!')
      return response.data.note
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to update note'
      toast.error(errorMessage)
      throw error
    }
  }

  const deleteNote = async (noteId) => {
    try {
      const response = await notesAPI.deleteNote(noteId)
      dispatch({ type: NotesActionTypes.DELETE_NOTE, payload: noteId })
      toast.success(response.data.message || 'Note deleted successfully!')
      return response.data
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to delete note'
      toast.error(errorMessage)
      throw error
    }
  }

  const bulkUpdateNotes = async (operation, noteIds, updates = {}) => {
    try {
      const response = await notesAPI.bulkOperations({ operation, noteIds })
      dispatch({
        type: NotesActionTypes.BULK_UPDATE_NOTES,
        payload: {
          operation,
          noteIds,
          updates,
        },
      })
      toast.success(response.data.message || 'Operation completed successfully!')
      return response.data
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Bulk operation failed'
      toast.error(errorMessage)
      throw error
    }
  }

  const fetchTags = async () => {
    try {
      const response = await notesAPI.getTags()
      dispatch({ type: NotesActionTypes.SET_TAGS, payload: response.data.tags })
      return response.data.tags
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to fetch tags'
      toast.error(errorMessage)
      throw error
    }
  }

  const searchNotes = async (query, limit = 10) => {
    try {
      const response = await notesAPI.searchNotes({ q: query, limit })
      return response.data.notes
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Search failed'
      toast.error(errorMessage)
      throw error
    }
  }

  const setFilters = (newFilters) => {
    dispatch({ type: NotesActionTypes.SET_FILTERS, payload: newFilters })
  }

  const setCurrentNote = (note) => {
    dispatch({ type: NotesActionTypes.SET_CURRENT_NOTE, payload: note })
  }

  const clearError = () => {
    dispatch({ type: NotesActionTypes.CLEAR_ERROR })
  }

  const resetNotes = () => {
    dispatch({ type: NotesActionTypes.RESET_NOTES })
  }

  const value = {
    ...state,
    fetchNotes,
    fetchNote,
    createNote,
    updateNote,
    deleteNote,
    bulkUpdateNotes,
    fetchTags,
    searchNotes,
    setFilters,
    setCurrentNote,
    clearError,
    resetNotes,
  }

  return (
    <NotesContext.Provider value={value}>
      {children}
    </NotesContext.Provider>
  )
}
export const useNotes = () => {
  const context = useContext(NotesContext)
  if (!context) {
    throw new Error('useNotes must be used within a NotesProvider')
  }
  return context
}
export default NotesContext
