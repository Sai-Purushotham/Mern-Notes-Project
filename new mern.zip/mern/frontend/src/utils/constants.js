// API Configuration
export const API_CONFIG = {
  BASE_URL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api',
  TIMEOUT: 10000,
  RETRY_ATTEMPTS: 3,
  RETRY_DELAY: 1000
}

// App Configuration
export const APP_CONFIG = {
  NAME: import.meta.env.VITE_APP_NAME || 'Notes App',
  VERSION: import.meta.env.VITE_APP_VERSION || '1.0.0',
  DESCRIPTION: 'A modern notes management application'
}

// UI Constants
export const UI_CONSTANTS = {
  SIDEBAR_WIDTH: 256,
  HEADER_HEIGHT: 64,
  MOBILE_BREAKPOINT: 768,
  TABLET_BREAKPOINT: 1024,
  DESKTOP_BREAKPOINT: 1280
}

// Note Colors
export const NOTE_COLORS = [
  { name: 'default', value: '#ffffff', label: 'Default' },
  { name: 'red', value: '#fef2f2', label: 'Red' },
  { name: 'orange', value: '#fff7ed', label: 'Orange' },
  { name: 'yellow', value: '#fefce8', label: 'Yellow' },
  { name: 'green', value: '#f0fdf4', label: 'Green' },
  { name: 'blue', value: '#eff6ff', label: 'Blue' },
  { name: 'purple', value: '#faf5ff', label: 'Purple' },
  { name: 'pink', value: '#fdf2f8', label: 'Pink' }
]

// Sorting Options
export const SORT_OPTIONS = [
  { value: 'createdAt', label: 'Date Created', order: 'desc' },
  { value: 'updatedAt', label: 'Last Modified', order: 'desc' },
  { value: 'title', label: 'Title A-Z', order: 'asc' },
  { value: 'title', label: 'Title Z-A', order: 'desc' },
  { value: 'isPinned', label: 'Pinned First', order: 'desc' }
]

// Pagination
export const PAGINATION = {
  DEFAULT_PAGE_SIZE: 10,
  PAGE_SIZE_OPTIONS: [10, 20, 50, 100],
  MAX_PAGE_SIZE: 100
}

// Form Validation
export const VALIDATION = {
  EMAIL_REGEX: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
  PASSWORD_MIN_LENGTH: 6,
  PASSWORD_MAX_LENGTH: 128,
  NAME_MIN_LENGTH: 1,
  NAME_MAX_LENGTH: 50,
  NOTE_TITLE_MAX_LENGTH: 100,
  NOTE_CONTENT_MAX_LENGTH: 10000,
  TAG_MAX_LENGTH: 30,
  MAX_TAGS_PER_NOTE: 10
}

// Local Storage Keys
export const STORAGE_KEYS = {
  TOKEN: 'token',
  USER: 'user',
  THEME: 'theme',
  NOTES_FILTERS: 'notes_filters',
  NOTES_VIEW: 'notes_view',
  SIDEBAR_COLLAPSED: 'sidebar_collapsed',
  RECENT_SEARCHES: 'recent_searches',
  EDITOR_PREFERENCES: 'editor_preferences'
}

// Error Messages
export const ERROR_MESSAGES = {
  NETWORK_ERROR: 'Network error. Please check your connection.',
  SERVER_ERROR: 'Server error. Please try again later.',
  UNAUTHORIZED: 'You are not authorized to perform this action.',
  FORBIDDEN: 'Access denied.',
  NOT_FOUND: 'The requested resource was not found.',
  VALIDATION_ERROR: 'Please check your input and try again.',
  UNKNOWN_ERROR: 'An unexpected error occurred.'
}

// Success Messages
export const SUCCESS_MESSAGES = {
  LOGIN_SUCCESS: 'Welcome back!',
  LOGOUT_SUCCESS: 'You have been logged out successfully.',
  REGISTER_SUCCESS: 'Account created successfully!',
  NOTE_CREATED: 'Note created successfully!',
  NOTE_UPDATED: 'Note updated successfully!',
  NOTE_DELETED: 'Note deleted successfully!',
  PROFILE_UPDATED: 'Profile updated successfully!',
  PASSWORD_CHANGED: 'Password changed successfully!'
}

// HTTP Status Codes
export const HTTP_STATUS = {
  OK: 200,
  CREATED: 201,
  NO_CONTENT: 204,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  UNPROCESSABLE_ENTITY: 422,
  INTERNAL_SERVER_ERROR: 500,
  BAD_GATEWAY: 502,
  SERVICE_UNAVAILABLE: 503
}

// File Upload
export const FILE_UPLOAD = {
  MAX_FILE_SIZE: 5 * 1024 * 1024, // 5MB
  ALLOWED_IMAGE_TYPES: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
  ALLOWED_DOCUMENT_TYPES: ['application/pdf', 'text/plain', 'text/markdown'],
  ALLOWED_EXTENSIONS: ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf', 'txt', 'md']
}

// Theme Configuration
export const THEMES = {
  LIGHT: {
    name: 'light',
    label: 'Light',
    colors: {
      primary: '#3b82f6',
      background: '#ffffff',
      surface: '#f8fafc',
      text: '#1f2937'
    }
  },
  DARK: {
    name: 'dark',
    label: 'Dark',
    colors: {
      primary: '#60a5fa',
      background: '#111827',
      surface: '#1f2937',
      text: '#f9fafb'
    }
  }
}

// Keyboard Shortcuts
export const KEYBOARD_SHORTCUTS = {
  NEW_NOTE: ['ctrl', 'n'],
  SAVE_NOTE: ['ctrl', 's'],
  SEARCH: ['ctrl', 'k'],
  TOGGLE_SIDEBAR: ['ctrl', 'b'],
  DELETE_NOTE: ['ctrl', 'delete'],
  PIN_NOTE: ['ctrl', 'p'],
  ARCHIVE_NOTE: ['ctrl', 'e']
}

// Animation Durations (in milliseconds)
export const ANIMATION_DURATION = {
  FAST: 150,
  NORMAL: 300,
  SLOW: 500,
  EXTRA_SLOW: 1000
}

// Feature Flags
export const FEATURE_FLAGS = {
  DARK_MODE: true,
  OFFLINE_MODE: false,
  COLLABORATIVE_EDITING: false,
  EXPORT_NOTES: true,
  IMPORT_NOTES: true,
  NOTE_SHARING: false,
  RICH_TEXT_EDITOR: false,
  VOICE_NOTES: false,
  AI_SUGGESTIONS: false
}

// Environment
export const ENVIRONMENT = {
  IS_DEVELOPMENT: import.meta.env.DEV,
  IS_PRODUCTION: import.meta.env.PROD,
  NODE_ENV: import.meta.env.MODE
}

export default {
  API_CONFIG,
  APP_CONFIG,
  UI_CONSTANTS,
  NOTE_COLORS,
  SORT_OPTIONS,
  PAGINATION,
  VALIDATION,
  STORAGE_KEYS,
  ERROR_MESSAGES,
  SUCCESS_MESSAGES,
  HTTP_STATUS,
  FILE_UPLOAD,
  THEMES,
  KEYBOARD_SHORTCUTS,
  ANIMATION_DURATION,
  FEATURE_FLAGS,
  ENVIRONMENT
}
