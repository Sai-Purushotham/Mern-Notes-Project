const User = require('./User');
const Note = require('./Note');

module.exports = {
  User,
  Note
};
