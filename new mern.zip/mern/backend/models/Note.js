const mongoose = require('mongoose');

const noteSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Please provide a title'],
    maxlength: [100, 'Title cannot be more than 100 characters'],
    trim: true
  },
  content: {
    type: String,
    required: [true, 'Please provide content'],
    maxlength: [10000, 'Content cannot be more than 10000 characters']
  },
  tags: [{
    type: String,
    trim: true,
    lowercase: true,
    maxlength: [30, 'Tag cannot be more than 30 characters']
  }],
  user: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: true
  },
  isPinned: {
    type: Boolean,
    default: false
  },
  isArchived: {
    type: Boolean,
    default: false
  },
  color: {
    type: String,
    enum: ['default', 'red', 'orange', 'yellow', 'green', 'blue', 'purple', 'pink'],
    default: 'default'
  },
  reminder: {
    type: Date,
    default: null
  },
  sharedWith: [{
    user: {
      type: mongoose.Schema.ObjectId,
      ref: 'User'
    },
    permission: {
      type: String,
      enum: ['read', 'write'],
      default: 'read'
    }
  }]
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual for formatted creation date
noteSchema.virtual('formattedCreatedAt').get(function() {
  return this.createdAt.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
});

// Virtual for formatted update date
noteSchema.virtual('formattedUpdatedAt').get(function() {
  return this.updatedAt.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
});

// Virtual for content preview
noteSchema.virtual('contentPreview').get(function() {
  return this.content.length > 100 ? 
    this.content.substring(0, 100) + '...' : 
    this.content;
});

// Indexes for better performance
noteSchema.index({ user: 1, createdAt: -1 });
noteSchema.index({ user: 1, title: 'text', content: 'text' });
noteSchema.index({ user: 1, tags: 1 });
noteSchema.index({ user: 1, isPinned: -1, createdAt: -1 });
noteSchema.index({ reminder: 1 });

// Pre-save middleware to clean up tags
noteSchema.pre('save', function(next) {
  // Remove empty tags and duplicates
  if (this.tags) {
    this.tags = [...new Set(this.tags.filter(tag => tag.trim() !== ''))];
  }
  next();
});

// Static method to get user notes with pagination
noteSchema.statics.getUserNotes = function(userId, options = {}) {
  const {
    page = 1,
    limit = 10,
    search = '',
    tags = [],
    sortBy = 'createdAt',
    sortOrder = 'desc',
    archived = false,
    pinned = null
  } = options;

  const query = { user: userId };

  // Add search functionality
  if (search) {
    query.$or = [
      { title: { $regex: search, $options: 'i' } },
      { content: { $regex: search, $options: 'i' } }
    ];
  }

  // Filter by tags
  if (tags.length > 0) {
    query.tags = { $in: tags };
  }

  // Filter by archived status
  query.isArchived = archived;

  // Filter by pinned status
  if (pinned !== null) {
    query.isPinned = pinned;
  }

  const sort = {};
  sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

  // If sorting by pinned, add secondary sort
  if (sortBy !== 'isPinned') {
    sort.isPinned = -1; // Pinned notes first
  }

  const skip = (page - 1) * limit;

  return this.find(query)
    .sort(sort)
    .skip(skip)
    .limit(parseInt(limit))
    .populate('user', 'name email')
    .populate('sharedWith.user', 'name email');
};

// Static method to get all tags for a user
noteSchema.statics.getUserTags = function(userId) {
  return this.aggregate([
    { $match: { user: mongoose.Types.ObjectId(userId) } },
    { $unwind: '$tags' },
    { $group: { _id: '$tags', count: { $sum: 1 } } },
    { $sort: { count: -1, _id: 1 } }
  ]);
};

module.exports = mongoose.model('Note', noteSchema);
