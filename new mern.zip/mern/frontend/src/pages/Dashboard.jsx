import React, { useEffect, useState } from 'react'
import { useSearchParams, Link } from 'react-router-dom'
import {
  Plus,
  Grid,
  List,
  Filter,
  Search,
  Pin,
  Archive,
  Trash2,
  Edit3,
  Calendar,
  Tag,
  MoreVertical
} from 'lucide-react'
import { useNotes } from '../context/NotesContext'
import { useAuth } from '../context/AuthContext'
import LoadingSpinner from '../components/LoadingSpinner'
import { format } from 'date-fns'

const Dashboard = () => {
  const { user } = useAuth()
  const {
    notes,
    loading,
    pagination,
    fetchNotes,
    deleteNote,
    updateNote,
    tags,
    fetchTags
  } = useNotes()

  const [searchParams, setSearchParams] = useSearchParams()
  const [viewMode, setViewMode] = useState('grid') // 'grid' or 'list'
  const [selectedNotes, setSelectedNotes] = useState([])
  const [showFilters, setShowFilters] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')

  // Get query parameters
  const archived = searchParams.get('archived') === 'true'
  const pinned = searchParams.get('pinned') === 'true' ? true : null
  const tagFilter = searchParams.get('tag') || ''

  useEffect(() => {
    const params = {
      archived,
      pinned,
      search: searchQuery,
      ...(tagFilter && { tags: [tagFilter] })
    }

    fetchNotes(params)
    fetchTags()
  }, [fetchNotes, fetchTags, archived, pinned, searchQuery, tagFilter])

  const handleSearch = (query) => {
    setSearchQuery(query)
  }

  const handleTogglePin = async (noteId, currentPinned) => {
    try {
      await updateNote(noteId, { isPinned: !currentPinned })
    } catch (error) {
      console.error('Error toggling pin:', error)
    }
  }

  const handleToggleArchive = async (noteId, currentArchived) => {
    try {
      await updateNote(noteId, { isArchived: !currentArchived })
    } catch (error) {
      console.error('Error toggling archive:', error)
    }
  }

  const handleDeleteNote = async (noteId) => {
    if (window.confirm('Are you sure you want to delete this note?')) {
      try {
        await deleteNote(noteId)
      } catch (error) {
        console.error('Error deleting note:', error)
      }
    }
  }

  const handleNoteSelect = (noteId) => {
    setSelectedNotes(prev =>
      prev.includes(noteId)
        ? prev.filter(id => id !== noteId)
        : [...prev, noteId]
    )
  }

  const getPageTitle = () => {
    if (archived) return 'Archived Notes'
    if (pinned) return 'Pinned Notes'
    if (tagFilter) return `Notes tagged with "${tagFilter}"`
    return 'All Notes'
  }

  const getNoteCardClass = (note) => {
    let baseClass = 'note-card'
    if (note.color && note.color !== 'default') {
      baseClass += ` note-card-${note.color}`
    }
    if (selectedNotes.includes(note._id)) {
      baseClass += ' ring-2 ring-primary-500'
    }
    return baseClass
  }

  if (loading && notes.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="large" text="Loading notes..." />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{getPageTitle()}</h1>
          <p className="text-gray-600">
            Welcome back, {user?.name}! You have {pagination.totalNotes} notes.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {/* View mode toggle */}
          <div className="flex items-center bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-md transition-colors ${
                viewMode === 'grid' ? 'bg-white shadow text-primary-600' : 'text-gray-500'
              }`}
            >
              <Grid size={18} />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-md transition-colors ${
                viewMode === 'list' ? 'bg-white shadow text-primary-600' : 'text-gray-500'
              }`}
            >
              <List size={18} />
            </button>
          </div>

          {/* Filters toggle */}
          <button onClick={() => setShowFilters(!showFilters)} className="btn-secondary flex items-center space-x-2">
            <Filter size={18} />
            <span>Filters</span>
          </button>

          {/* New note button */}
          <Link to="/notes/new" className="btn-primary flex items-center space-x-2">
            <Plus size={18} />
            <span className="hidden sm:block">New Note</span>
          </Link>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4">
        {/* Search */}
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="Search notes..."
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
          />
        </div>

        {/* Filter tags */}
        {showFilters && tags.length > 0 && (
          <div className="bg-white p-4 rounded-lg border border-gray-200">
            <h3 className="text-sm font-medium text-gray-700 mb-3">Filter by tags:</h3>
            <div className="flex flex-wrap gap-2">
              {tags.map((tag) => (
                <button
                  key={tag.name}
                  onClick={() => {
                    if (tagFilter === tag.name) {
                      searchParams.delete('tag')
                    } else {
                      searchParams.set('tag', tag.name)
                    }
                    setSearchParams(searchParams)
                  }}
                  className={`inline-flex items-center px-3 py-1 rounded-full text-sm transition-colors ${
                    tagFilter === tag.name
                      ? 'bg-primary-100 text-primary-700 border border-primary-300'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  <Tag size={14} className="mr-1" />
                  {tag.name}
                  <span className="ml-1 text-xs opacity-75">({tag.count})</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Bulk actions */}
      {selectedNotes.length > 0 && (
        <div className="bg-primary-50 border border-primary-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-primary-700">{selectedNotes.length} note{selectedNotes.length > 1 ? 's' : ''} selected</p>
            <div className="flex items-center space-x-2">
              <button className="btn-secondary text-sm">Archive</button>
              <button className="btn-secondary text-sm">Delete</button>
              <button onClick={() => setSelectedNotes([])} className="btn-ghost text-sm">Clear</button>
            </div>
          </div>
        </div>
      )}

      {/* Notes Grid/List */}
      {notes.length === 0 ? (
        <div className="text-center py-12">
          <div className="mx-auto h-24 w-24 text-gray-300 mb-4">
            <svg fill="currentColor" viewBox="0 0 24 24">
              <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z" />
              <path d="M14 2v6h6M16 13H8M16 17H8M10 9H8" />
            </svg>
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No notes found</h3>
          <p className="text-gray-600 mb-4">
            {searchQuery
              ? `No notes match "${searchQuery}"`
              : archived
              ? "You don't have any archived notes"
              : pinned
              ? "You don't have any pinned notes"
              : "Get started by creating your first note"
            }
          </p>
          {!searchQuery && (
            <Link to="/notes/new" className="btn-primary inline-flex items-center space-x-2">
              <Plus size={18} />
              <span>Create your first note</span>
            </Link>
          )}
        </div>
      ) : (
        <div
          className={`${viewMode === 'grid' ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4' : 'space-y-3'}`}
        >
          {notes.map(note => (
            <NoteCard
              key={note._id}
              note={note}
              viewMode={viewMode}
              isSelected={selectedNotes.includes(note._id)}
              onSelect={handleNoteSelect}
              onTogglePin={handleTogglePin}
              onToggleArchive={handleToggleArchive}
              onDelete={handleDeleteNote}
              className={getNoteCardClass(note)}
            />
          ))}
        </div>
      )}

      {/* Pagination */}
      {pagination.totalPages > 1 && (
        <div className="flex items-center justify-between border-t border-gray-200 bg-white px-4 py-3 sm:px-6 rounded-lg">
          <div className="flex flex-1 justify-between sm:hidden">
            <button
              disabled={!pagination.hasPrevPage}
              className="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Previous
            </button>
            <button
              disabled={!pagination.hasNextPage}
              className="relative ml-3 inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next
            </button>
          </div>
          <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">
            <div>
              <p className="text-sm text-gray-700">
                Showing{' '}
                <span className="font-medium">{(pagination.currentPage - 1) * 10 + 1}</span>{' '}
                to{' '}
                <span className="font-medium">{Math.min(pagination.currentPage * 10, pagination.totalNotes)}</span>{' '}
                of{' '}
                <span className="font-medium">{pagination.totalNotes}</span>{' '}
                results
              </p>
            </div>
            <div>
              <nav className="isolate inline-flex -space-x-px rounded-md shadow-sm">
                <button
                  disabled={!pagination.hasPrevPage}
                  className="relative inline-flex items-center rounded-l-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Previous
                </button>
                {/* Page numbers can be added here */}
                <button
                  disabled={!pagination.hasNextPage}
                  className="relative inline-flex items-center rounded-r-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Next
                </button>
              </nav>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

const NoteCard = ({ note, viewMode, isSelected, onSelect, onTogglePin, onToggleArchive, onDelete, className }) => {
  const [showMenu, setShowMenu] = useState(false)

  const handleCardClick = (e) => {
    if (e.target.closest('.note-actions')) {
      e.preventDefault()
      return
    }
  }

  return (
    <div className={`${className} relative group`} onClick={handleCardClick}>
      {/* Selection checkbox */}
      <div className="absolute top-2 left-2 opacity-0 group-hover:opacity-100 transition-opacity note-actions">
        <input
          type="checkbox"
          checked={isSelected}
          onChange={() => onSelect(note._id)}
          className="h-4 w-4 text-primary-600 rounded border-gray-300"
        />
      </div>

      {/* Pin indicator */}
      {note.isPinned && (
        <div className="absolute top-2 right-8">
          <Pin size={16} className="text-yellow-500 fill-current" />
        </div>
      )}

      {/* Actions menu */}
      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity note-actions">
        <div className="relative">
          <button onClick={() => setShowMenu(!showMenu)} className="p-1 rounded-full hover:bg-gray-100 text-gray-500">
            <MoreVertical size={16} />
          </button>
          {showMenu && (
            <div className="absolute right-0 mt-1 w-32 bg-white border border-gray-200 rounded-md shadow-lg z-10">
              <Link
                to={`/notes/${note._id}/edit`}
                className="flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50"
              >
                <Edit3 size={14} />
                <span>Edit</span>
              </Link>
              <button
                onClick={() => onTogglePin(note._id, note.isPinned)}
                className="flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 w-full text-left"
              >
                <Pin size={14} />
                <span>{note.isPinned ? 'Unpin' : 'Pin'}</span>
              </button>
              <button
                onClick={() => onToggleArchive(note._id, note.isArchived)}
                className="flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 w-full text-left"
              >
                <Archive size={14} />
                <span>{note.isArchived ? 'Unarchive' : 'Archive'}</span>
              </button>
              <button
                onClick={() => onDelete(note._id)}
                className="flex items-center space-x-2 px-3 py-2 text-sm text-red-600 hover:bg-red-50 w-full text-left"
              >
                <Trash2 size={14} />
                <span>Delete</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Note content */}
      <Link to={`/notes/${note._id}/edit`} className="block">
        <div className={viewMode === 'grid' ? 'space-y-3' : 'flex items-start space-x-4'}>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-gray-900 truncate mb-2">{note.title}</h3>
            <p className={`text-gray-600 text-sm ${viewMode === 'grid' ? 'truncate-lines-3' : 'truncate-lines-2'}`}>
              {note.contentPreview || note.content}
            </p>

            {/* Tags */}
            {note.tags && note.tags.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-3">
                {note.tags.slice(0, 3).map((tag, index) => (
                  <span key={index} className="inline-block px-2 py-1 text-xs bg-gray-100 text-gray-600 rounded">
                    {tag}
                  </span>
                ))}
                {note.tags.length > 3 && <span className="text-xs text-gray-500">+{note.tags.length - 3} more</span>}
              </div>
            )}

            {/* Metadata */}
            <div className="flex items-center justify-between mt-3 text-xs text-gray-500">
              <div className="flex items-center space-x-1">
                <Calendar size={12} />
                <span>{format(new Date(note.updatedAt), 'MMM d, yyyy')}</span>
              </div>
              {note.reminder && (
                <div className="flex items-center space-x-1 text-orange-600">
                  <Calendar size={12} />
                  <span>Reminder</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </Link>
    </div>
  )
}

export default Dashboard
