import React, { useState, useEffect } from 'react'
import { useNavigate, useParams, Link } from 'react-router-dom'
import {
  Save,
  ArrowLeft,
  Pin,
  Archive,
  Trash2,
  Tag,
  Palette,
  Calendar,
  MoreVertical
} from 'lucide-react'
import TextareaAutosize from 'react-textarea-autosize'
import { useNotes } from '../context/NotesContext'
import LoadingSpinner from '../components/LoadingSpinner'
import { format } from 'date-fns'
import toast from 'react-hot-toast'

const NoteEditor = () => {
  const navigate = useNavigate()
  const { id } = useParams()
  const isEditing = Boolean(id)

  const {
    currentNote,
    fetchNote,
    createNote,
    updateNote,
    deleteNote,
    loading
  } = useNotes()

  const [noteData, setNoteData] = useState({
    title: '',
    content: '',
    tags: [],
    color: 'default',
    isPinned: false,
    isArchived: false,
    reminder: ''
  })

  const [newTag, setNewTag] = useState('')
  const [showColorPicker, setShowColorPicker] = useState(false)
  const [showMoreOptions, setShowMoreOptions] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false)

  const colors = [
    { name: 'default', class: 'bg-white', label: 'Default' },
    { name: 'red', class: 'bg-red-50', label: 'Red' },
    { name: 'orange', class: 'bg-orange-50', label: 'Orange' },
    { name: 'yellow', class: 'bg-yellow-50', label: 'Yellow' },
    { name: 'green', class: 'bg-green-50', label: 'Green' },
    { name: 'blue', class: 'bg-blue-50', label: 'Blue' },
    { name: 'purple', class: 'bg-purple-50', label: 'Purple' },
    { name: 'pink', class: 'bg-pink-50', label: 'Pink' }
  ]

  // Load note data if editing
  useEffect(() => {
    if (isEditing && id) {
      fetchNote(id)
    }
  }, [isEditing, id, fetchNote])

  // Set note data when currentNote changes
  useEffect(() => {
    if (isEditing && currentNote) {
      setNoteData({
        title: currentNote.title || '',
        content: currentNote.content || '',
        tags: currentNote.tags || [],
        color: currentNote.color || 'default',
        isPinned: currentNote.isPinned || false,
        isArchived: currentNote.isArchived || false,
        reminder: currentNote.reminder ? currentNote.reminder.split('T')[0] : ''
      })
    }
  }, [isEditing, currentNote])

  // Handle form changes
  const handleChange = (field, value) => {
    setNoteData(prev => ({ ...prev, [field]: value }))
    setHasUnsavedChanges(true)
  }

  // Add tag
  const handleAddTag = () => {
    if (newTag.trim() && !noteData.tags.includes(newTag.trim())) {
      handleChange('tags', [...noteData.tags, newTag.trim().toLowerCase()])
      setNewTag('')
    }
  }

  // Remove tag
  const handleRemoveTag = (tagToRemove) => {
    handleChange('tags', noteData.tags.filter(tag => tag !== tagToRemove))
  }

  // Handle tag input key press
  const handleTagKeyPress = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      handleAddTag()
    }
  }

  // Save note
  const handleSave = async () => {
    if (!noteData.title.trim()) {
      toast.error('Please enter a title for your note')
      return
    }
    if (!noteData.content.trim()) {
      toast.error('Please enter some content for your note')
      return
    }

    setIsSaving(true)

    try {
      const saveData = {
        ...noteData,
        title: noteData.title.trim(),
        content: noteData.content.trim(),
        reminder: noteData.reminder || null
      }
      if (isEditing) {
        await updateNote(id, saveData)
      } else {
        const newNote = await createNote(saveData)
        navigate(`/notes/${newNote._id}/edit`, { replace: true })
      }
      setHasUnsavedChanges(false)
    } catch (error) {
      console.error('Error saving note:', error)
    } finally {
      setIsSaving(false)
    }
  }

  // Delete note
  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this note? This action cannot be undone.')) {
      try {
        await deleteNote(id)
        navigate('/dashboard')
      } catch (error) {
        console.error('Error deleting note:', error)
      }
    }
  }

  // Warn on unsaved changes when navigating away
  useEffect(() => {
    const handleBeforeUnload = (e) => {
      if (hasUnsavedChanges) {
        e.preventDefault()
        e.returnValue = ''
      }
    }
    window.addEventListener('beforeunload', handleBeforeUnload)
    return () => window.removeEventListener('beforeunload', handleBeforeUnload)
  }, [hasUnsavedChanges])

  if (loading && isEditing) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="large" text="Loading note..." />
      </div>
    )
  }

  const selectedColor = colors.find(c => c.name === noteData.color) || colors[0]

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <Link to="/dashboard" className="btn-ghost flex items-center space-x-2">
            <ArrowLeft size={18} />
            <span>Back to Notes</span>
          </Link>
          {isEditing && currentNote && (
            <div className="text-sm text-gray-500">
              Last edited {format(new Date(currentNote.updatedAt), "MMM d, yyyy 'at' h:mm a")}
            </div>
          )}
        </div>
        <div className="flex items-center space-x-2">
          {/* Color picker */}
          <div className="relative">
            <button onClick={() => setShowColorPicker(!showColorPicker)} className="btn-ghost flex items-center space-x-2">
              <Palette size={18} />
              <span className="hidden sm:block">Color</span>
            </button>
            {showColorPicker && (
              <div className="absolute right-0 mt-2 p-3 bg-white border border-gray-200 rounded-lg shadow-lg z-10 grid grid-cols-4 gap-2">
                {colors.map(color => (
                  <button
                    key={color.name}
                    onClick={() => {
                      handleChange('color', color.name)
                      setShowColorPicker(false)
                    }}
                    className={`w-8 h-8 rounded-full border-2 transition-all ${color.class} ${color.name === noteData.color ? 'border-primary-500 ring-2 ring-primary-200' : 'border-gray-300 hover:border-gray-400'}`}
                    title={color.label}
                  />
                ))}
              </div>
            )}
          </div>

          {/* More options */}
          {isEditing && (
            <div className="relative">
              <button onClick={() => setShowMoreOptions(!showMoreOptions)} className="btn-ghost">
                <MoreVertical size={18} />
              </button>
              {showMoreOptions && (
                <div className="absolute right-0 mt-2 w-40 bg-white border border-gray-200 rounded-lg shadow-lg z-10">
                  <button
                    onClick={() => {
                      handleChange('isPinned', !noteData.isPinned)
                      setShowMoreOptions(false)
                    }}
                    className="flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 w-full text-left"
                  >
                    <Pin size={14} />
                    <span>{noteData.isPinned ? 'Unpin' : 'Pin'} Note</span>
                  </button>

                  <button
                    onClick={() => {
                      handleChange('isArchived', !noteData.isArchived)
                      setShowMoreOptions(false)
                    }}
                    className="flex items-center space-x-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 w-full text-left"
                  >
                    <Archive size={14} />
                    <span>{noteData.isArchived ? 'Unarchive' : 'Archive'}</span>
                  </button>

                  <hr className="my-1" />

                  <button
                    onClick={() => {
                      handleDelete()
                      setShowMoreOptions(false)
                    }}
                    className="flex items-center space-x-2 px-3 py-2 text-sm text-red-600 hover:bg-red-50 w-full text-left"
                  >
                    <Trash2 size={14} />
                    <span>Delete Note</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Save button */}
          <button
            onClick={handleSave}
            disabled={isSaving || !hasUnsavedChanges}
            className="btn-primary flex items-center space-x-2"
          >
            {isSaving ? <LoadingSpinner size="small" color="white" /> : <Save size={18} />}
            <span>{isEditing ? 'Update' : 'Save'}</span>
          </button>
        </div>
      </div>

      {/* Note Editor */}
      <div className={`card rounded-lg p-6 transition-colors ${selectedColor.class} ${selectedColor.name !== 'default' ? 'border-opacity-50' : ''}`}>
        {/* Title */}
        <input
          type="text"
          placeholder="Note title..."
          value={noteData.title}
          onChange={(e) => handleChange('title', e.target.value)}
          className="w-full text-2xl font-bold bg-transparent border-none outline-none resize-none placeholder-gray-400 text-gray-900 mb-4"
        />

        {/* Content */}
        <TextareaAutosize
          placeholder="Start writing your note..."
          value={noteData.content}
          onChange={(e) => handleChange('content', e.target.value)}
          minRows={10}
          className="w-full bg-transparent border-none outline-none resize-none placeholder-gray-400 text-gray-700 leading-relaxed"
        />

        {/* Tags Section */}
        <div className="mt-6 pt-6 border-t border-gray-200">
          <div className="flex items-center space-x-2 mb-3">
            <Tag size={16} className="text-gray-500" />
            <span className="text-sm font-medium text-gray-700">Tags</span>
          </div>

          {/* Existing tags */}
          {noteData.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-3">
              {noteData.tags.map((tag, index) => (
                <span key={index} className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-primary-100 text-primary-700">
                  {tag}
                  <button onClick={() => handleRemoveTag(tag)} className="ml-2 text-primary-500 hover:text-primary-700">×</button>
                </span>
              ))}
            </div>
          )}

          {/* Add new tag */}
          <div className="flex items-center space-x-2">
            <input
              type="text"
              placeholder="Add a tag..."
              value={newTag}
              onChange={(e) => setNewTag(e.target.value)}
              onKeyPress={handleTagKeyPress}
              className="flex-1 px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            />
            <button onClick={handleAddTag} disabled={!newTag.trim()} className="btn-secondary text-sm">
              Add Tag
            </button>
          </div>
        </div>

        {/* Reminder Section */}
        <div className="mt-6 pt-6 border-t border-gray-200">
          <div className="flex items-center space-x-2 mb-3">
            <Calendar size={16} className="text-gray-500" />
            <span className="text-sm font-medium text-gray-700">Reminder</span>
          </div>

          <input
            type="date"
            value={noteData.reminder}
            onChange={(e) => handleChange('reminder', e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
          />
        </div>
      </div>

      {/* Unsaved changes warning */}
      {hasUnsavedChanges && (
        <div className="fixed bottom-4 right-4 bg-orange-100 border border-orange-300 text-orange-700 px-4 py-2 rounded-lg text-sm">
          You have unsaved changes
        </div>
      )}
    </div>
  )
}

export default NoteEditor
