// HTTP Status Codes
const HTTP_STATUS = {
  OK: 200,
  CREATED: 201,
  NO_CONTENT: 204,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  UNPROCESSABLE_ENTITY: 422,
  INTERNAL_SERVER_ERROR: 500
};

// Note colors
const NOTE_COLORS = [
  'default',
  'red',
  'orange', 
  'yellow',
  'green',
  'blue',
  'purple',
  'pink'
];

// Sort options for notes
const SORT_OPTIONS = {
  CREATED_AT: 'createdAt',
  UPDATED_AT: 'updatedAt',
  TITLE: 'title',
  IS_PINNED: 'isPinned'
};

// Default pagination settings
const PAGINATION_DEFAULTS = {
  PAGE: 1,
  LIMIT: 10,
  MAX_LIMIT: 100
};

// Validation constants
const VALIDATION_RULES = {
  USER: {
    NAME_MIN_LENGTH: 1,
    NAME_MAX_LENGTH: 50,
    EMAIL_MAX_LENGTH: 100,
    PASSWORD_MIN_LENGTH: 6,
    PASSWORD_MAX_LENGTH: 128
  },
  NOTE: {
    TITLE_MIN_LENGTH: 1,
    TITLE_MAX_LENGTH: 100,
    CONTENT_MIN_LENGTH: 1,
    CONTENT_MAX_LENGTH: 10000,
    MAX_TAGS: 10,
    TAG_MAX_LENGTH: 30
  }
};

// JWT settings
const JWT_SETTINGS = {
  DEFAULT_EXPIRE: '7d',
  ALGORITHM: 'HS256'
};

// Rate limiting settings
const RATE_LIMIT_SETTINGS = {
  WINDOW_MS: 15 * 60 * 1000, // 15 minutes
  MAX_REQUESTS: 100,
  AUTH_WINDOW_MS: 15 * 60 * 1000, // 15 minutes
  AUTH_MAX_REQUESTS: 5 // 5 login attempts per 15 minutes
};

// Error messages
const ERROR_MESSAGES = {
  // Authentication errors
  INVALID_CREDENTIALS: 'Invalid credentials',
  TOKEN_EXPIRED: 'Token expired. Please log in again.',
  TOKEN_INVALID: 'Invalid token. Please log in again.',
  ACCESS_DENIED: 'Access denied. Please log in.',
  INSUFFICIENT_PERMISSIONS: 'Insufficient permissions',

  // User errors
  USER_NOT_FOUND: 'User not found',
  USER_ALREADY_EXISTS: 'User already exists with this email',
  EMAIL_ALREADY_TAKEN: 'Email already taken',
  INCORRECT_PASSWORD: 'Incorrect password',

  // Note errors
  NOTE_NOT_FOUND: 'Note not found',
  NOTE_ACCESS_DENIED: 'Access denied to this note',

  // Validation errors
  VALIDATION_FAILED: 'Validation failed',
  REQUIRED_FIELD_MISSING: 'Required field missing',
  INVALID_INPUT: 'Invalid input provided',

  // Server errors
  INTERNAL_SERVER_ERROR: 'Internal server error',
  DATABASE_ERROR: 'Database connection error',

  // General errors
  RESOURCE_NOT_FOUND: 'Resource not found',
  OPERATION_FAILED: 'Operation failed'
};

// Success messages
const SUCCESS_MESSAGES = {
  // Authentication
  LOGIN_SUCCESS: 'Login successful',
  REGISTER_SUCCESS: 'User registered successfully',
  LOGOUT_SUCCESS: 'Logout successful',
  PASSWORD_CHANGED: 'Password changed successfully',
  PROFILE_UPDATED: 'Profile updated successfully',
  ACCOUNT_DELETED: 'Account deleted successfully',

  // Notes
  NOTE_CREATED: 'Note created successfully',
  NOTE_UPDATED: 'Note updated successfully',
  NOTE_DELETED: 'Note deleted successfully',
  NOTES_BULK_UPDATED: 'Notes updated successfully',

  // General
  OPERATION_SUCCESS: 'Operation completed successfully'
};

module.exports = {
  HTTP_STATUS,
  NOTE_COLORS,
  SORT_OPTIONS,
  PAGINATION_DEFAULTS,
  VALIDATION_RULES,
  JWT_SETTINGS,
  RATE_LIMIT_SETTINGS,
  ERROR_MESSAGES,
  SUCCESS_MESSAGES
};
