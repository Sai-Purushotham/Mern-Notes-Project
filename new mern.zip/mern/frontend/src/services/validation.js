// Validation utility functions

export const ValidationRules = {
  // User validation
  email: {
    required: true,
    pattern: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
    message: 'Please enter a valid email address'
  },

  password: {
    required: true,
    minLength: 6,
    maxLength: 128,
    pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
    message: 'Password must be at least 6 characters with uppercase, lowercase, and number'
  },

  name: {
    required: true,
    minLength: 1,
    maxLength: 50,
    pattern: /^[a-zA-Z\s]+$/,
    message: 'Name can only contain letters and spaces'
  },

  // Note validation
  noteTitle: {
    required: true,
    minLength: 1,
    maxLength: 100,
    message: 'Title must be between 1 and 100 characters'
  },

  noteContent: {
    required: true,
    minLength: 1,
    maxLength: 10000,
    message: 'Content must be between 1 and 10000 characters'
  },

  tag: {
    maxLength: 30,
    pattern: /^[a-zA-Z0-9\s-_]+$/,
    message: 'Tag can only contain letters, numbers, spaces, hyphens, and underscores'
  }
}

// Generic validation function
export const validateField = (value, rules) => {
  const errors = []

  // Required check
  if (rules.required && (!value || value.toString().trim() === '')) {
    errors.push('This field is required')
    return errors
  }

  // Skip other validations if field is empty and not required
  if (!value || value.toString().trim() === '') {
    return errors
  }

  const stringValue = value.toString().trim()

  // Length checks
  if (rules.minLength && stringValue.length < rules.minLength) {
    errors.push(`Minimum length is ${rules.minLength} characters`)
  }

  if (rules.maxLength && stringValue.length > rules.maxLength) {
    errors.push(`Maximum length is ${rules.maxLength} characters`)
  }

  // Pattern check
  if (rules.pattern && !rules.pattern.test(stringValue)) {
    errors.push(rules.message || 'Invalid format')
  }

  return errors
}

// Validate multiple fields
export const validateForm = (values, validationSchema) => {
  const errors = {}
  let isValid = true

  Object.keys(validationSchema).forEach(field => {
    const fieldErrors = validateField(values[field], validationSchema[field])
    if (fieldErrors.length > 0) {
      errors[field] = fieldErrors
      isValid = false
    }
  })

  return { isValid, errors }
}

// Specific validation functions
export const validateEmail = (email) => {
  return validateField(email, ValidationRules.email)
}

export const validatePassword = (password) => {
  return validateField(password, ValidationRules.password)
}

export const validateName = (name) => {
  return validateField(name, ValidationRules.name)
}

export const validateNoteTitle = (title) => {
  return validateField(title, ValidationRules.noteTitle)
}

export const validateNoteContent = (content) => {
  return validateField(content, ValidationRules.noteContent)
}

export const validateTag = (tag) => {
  return validateField(tag, ValidationRules.tag)
}

export const validateTags = (tags) => {
  if (!Array.isArray(tags)) {
    return ['Tags must be an array']
  }

  if (tags.length > 10) {
    return ['Maximum 10 tags allowed']
  }

  const errors = []
  tags.forEach((tag, index) => {
    const tagErrors = validateTag(tag)
    if (tagErrors.length > 0) {
      errors.push(`Tag ${index + 1}: ${tagErrors[0]}`)
    }
  })

  return errors
}

// Password strength checker
export const checkPasswordStrength = (password) => {
  if (!password) return { score: 0, feedback: 'Enter a password' }

  let score = 0
  const feedback = []

  if (password.length >= 8) score += 1
  else feedback.push('Use at least 8 characters')

  if (/[a-z]/.test(password)) score += 1
  else feedback.push('Add lowercase letters')

  if (/[A-Z]/.test(password)) score += 1
  else feedback.push('Add uppercase letters')

  if (/\d/.test(password)) score += 1
  else feedback.push('Add numbers')

  if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) score += 1
  else feedback.push('Add special characters')

  const strength = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong'][score]

  return {
    score,
    strength,
    feedback: feedback.join(', '),
    isStrong: score >= 4
  }
}

// Sanitize input to prevent XSS
export const sanitizeInput = (input) => {
  if (typeof input !== 'string') return input

  return input
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;')
}

// Validate file upload
export const validateFile = (file, options = {}) => {
  const {
    maxSize = 5 * 1024 * 1024,
    allowedTypes = ['image/jpeg', 'image/png', 'image/gif'],
    allowedExtensions = ['jpg', 'jpeg', 'png', 'gif']
  } = options

  const errors = []

  if (!file) {
    errors.push('Please select a file')
    return errors
  }

  if (file.size > maxSize) {
    errors.push(`File size must be less than ${(maxSize / (1024 * 1024)).toFixed(1)}MB`)
  }

  if (allowedTypes.length > 0 && !allowedTypes.includes(file.type)) {
    errors.push(`File type must be one of: ${allowedTypes.join(', ')}`)
  }

  const extension = file.name.split('.').pop().toLowerCase()
  if (allowedExtensions.length > 0 && !allowedExtensions.includes(extension)) {
    errors.push(`File extension must be one of: ${allowedExtensions.join(', ')}`)
  }

  return errors
}

export default {
  ValidationRules,
  validateField,
  validateForm,
  validateEmail,
  validatePassword,
  validateName,
  validateNoteTitle,
  validateNoteContent,
  validateTag,
  validateTags,
  checkPasswordStrength,
  sanitizeInput,
  validateFile
}
