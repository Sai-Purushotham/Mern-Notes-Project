import React, { useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Home, StickyNote, Archive, Tag, Settings, Star } from 'lucide-react'
import { useNotes } from '../context/NotesContext'

const Sidebar = ({ isOpen, onClose }) => {
  const location = useLocation()
  const { tags, fetchTags, filters, setFilters } = useNotes()

  useEffect(() => {
    fetchTags()
  }, [fetchTags])

  const sidebarItems = [
    { name: 'Dashboard', href: '/dashboard', icon: Home, active: location.pathname === '/dashboard' },
    { name: 'All Notes', href: '/dashboard?view=all', icon: StickyNote, active: location.pathname === '/dashboard' && !location.search },
    { name: 'Starred', href: '/dashboard?pinned=true', icon: Star, active: location.search.includes('pinned=true') },
    { name: 'Archived', href: '/dashboard?archived=true', icon: Archive, active: location.search.includes('archived=true') }
    // add more as needed
  ]

  const handleTagFilter = (tagName) => {
    setFilters({
      ...filters,
      tags: filters.tags.includes(tagName)
        ? filters.tags.filter(t => t !== tagName)
        : [...filters.tags, tagName]
    })
    onClose()
  }

  const clearFilters = () => {
    setFilters({
      search: '',
      tags: [],
      sortBy: 'createdAt',
      sortOrder: 'desc',
      archived: false,
      pinned: null,
    })
  }

  return (
    <aside>
      {/* Your sidebar markup */}
      <div>Sidebar goes here.</div>
    </aside>
  )
}

export default Sidebar
