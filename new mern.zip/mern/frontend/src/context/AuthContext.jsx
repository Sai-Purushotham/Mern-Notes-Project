import React, { createContext, useContext, useReducer, useEffect } from 'react'
import { authAPI } from '../services/api'
import toast from 'react-hot-toast'

const initialState = {
  user: null,
  token: localStorage.getItem('token'),
  loading: true,
  isAuthenticated: false,
}

const AuthActionTypes = {
  AUTH_START: 'AUTH_START',
  AUTH_SUCCESS: 'AUTH_SUCCESS',
  AUTH_FAIL: 'AUTH_FAIL',
  LOGOUT: 'LOGOUT',
  UPDATE_USER: 'UPDATE_USER',
  CLEAR_ERROR: 'CLEAR_ERROR',
}

const authReducer = (state, action) => {
  switch (action.type) {
    case AuthActionTypes.AUTH_START:
      return { ...state, loading: true, error: null }
    case AuthActionTypes.AUTH_SUCCESS:
      localStorage.setItem('token', action.payload.token)
      return { ...state, loading: false, isAuthenticated: true, user: action.payload.user, token: action.payload.token, error: null }
    case AuthActionTypes.AUTH_FAIL:
      localStorage.removeItem('token')
      return { ...state, loading: false, isAuthenticated: false, user: null, token: null, error: action.payload }
    case AuthActionTypes.LOGOUT:
      localStorage.removeItem('token')
      return { ...state, loading: false, isAuthenticated: false, user: null, token: null, error: null }
    case AuthActionTypes.UPDATE_USER:
      return { ...state, user: { ...state.user, ...action.payload } }
    case AuthActionTypes.CLEAR_ERROR:
      return { ...state, error: null }
    default: return state
  }
}

const AuthContext = createContext()

export const AuthProvider = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState)

  useEffect(() => {
    const loadUser = async () => {
      const token = localStorage.getItem('token')
      if (token) {
        try {
          const response = await authAPI.getMe()
          dispatch({ type: AuthActionTypes.AUTH_SUCCESS, payload: { user: response.data.user, token } })
        } catch (error) {
          dispatch({ type: AuthActionTypes.AUTH_FAIL, payload: error.response?.data?.message || 'Failed to load user' })
        }
      } else {
        dispatch({ type: AuthActionTypes.AUTH_FAIL, payload: null })
      }
    }
    loadUser()
  }, [])

  const login = async (credentials) => {
    try {
      dispatch({ type: AuthActionTypes.AUTH_START })
      const response = await authAPI.login(credentials)
      dispatch({ type: AuthActionTypes.AUTH_SUCCESS, payload: { user: response.data.user, token: response.data.token } })
      toast.success(response.data.message || 'Login successful!')
      return response.data
    } catch (error) {
      const message = error.response?.data?.message || 'Login failed'
      dispatch({ type: AuthActionTypes.AUTH_FAIL, payload: message })
      toast.error(message)
      throw error
    }
  }

  const register = async (userData) => {
    try {
      dispatch({ type: AuthActionTypes.AUTH_START })
      const response = await authAPI.register(userData)
      dispatch({ type: AuthActionTypes.AUTH_SUCCESS, payload: { user: response.data.user, token: response.data.token } })
      toast.success(response.data.message || 'Registration successful!')
      return response.data
    } catch (error) {
      const message = error.response?.data?.message || 'Registration failed'
      dispatch({ type: AuthActionTypes.AUTH_FAIL, payload: message })
      toast.error(message)
      throw error
    }
  }

  const logout = () => {
    dispatch({ type: AuthActionTypes.LOGOUT })
    toast.success('Logged out successfully!')
  }

  const updateProfile = async (profileData) => {
    try {
      const response = await authAPI.updateProfile(profileData)
      dispatch({ type: AuthActionTypes.UPDATE_USER, payload: response.data.user })
      toast.success(response.data.message || 'Profile updated successfully!')
      return response.data
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to update profile'
      toast.error(message)
      throw error
    }
  }

  const changePassword = async (passwordData) => {
    try {
      const response = await authAPI.changePassword(passwordData)
      toast.success(response.data.message || 'Password changed successfully!')
      return response.data
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to change password'
      toast.error(message)
      throw error
    }
  }

  const deleteAccount = async (password) => {
    try {
      const response = await authAPI.deleteAccount({ password })
      dispatch({ type: AuthActionTypes.LOGOUT })
      toast.success(response.data.message || 'Account deleted successfully!')
      return response.data
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to delete account'
      toast.error(message)
      throw error
    }
  }

  const clearError = () => {
    dispatch({ type: AuthActionTypes.CLEAR_ERROR })
  }

  const value = { ...state, login, register, logout, updateProfile, changePassword, deleteAccount, clearError }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used within an AuthProvider')
  return context
}

export default AuthContext
