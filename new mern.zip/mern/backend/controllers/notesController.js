const Note = require('../models/Note');
const mongoose = require('mongoose');

// @desc    Get all notes for logged in user
// @route   GET /api/notes
// @access  Private
const getNotes = async (req, res, next) => {
  try {
    const {
      page = 1,
      limit = 10,
      search = '',
      tags = '',
      sortBy = 'createdAt',
      sortOrder = 'desc',
      archived = 'false',
      pinned = null
    } = req.query;

    // Parse tags if provided
    const tagsArray = tags ? tags.split(',').map(tag => tag.trim()).filter(Boolean) : [];

    // Parse archived boolean
    const isArchived = archived === 'true';

    // Parse pinned boolean
    let isPinned = null;
    if (pinned === 'true') isPinned = true;
    if (pinned === 'false') isPinned = false;

    const options = {
      page: parseInt(page),
      limit: parseInt(limit),
      search,
      tags: tagsArray,
      sortBy,
      sortOrder,
      archived: isArchived,
      pinned: isPinned
    };

    // Get notes
    const notes = await Note.getUserNotes(req.user._id, options);

    // Get total count for pagination
    const query = { user: req.user._id };

    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { content: { $regex: search, $options: 'i' } }
      ];
    }

    if (tagsArray.length > 0) {
      query.tags = { $in: tagsArray };
    }

    query.isArchived = isArchived;

    if (isPinned !== null) {
      query.isPinned = isPinned;
    }

    const totalNotes = await Note.countDocuments(query);
    const totalPages = Math.ceil(totalNotes / limit);

    res.status(200).json({
      success: true,
      count: notes.length,
      totalNotes,
      totalPages,
      currentPage: parseInt(page),
      notes
    });

  } catch (error) {
    console.error('GetNotes error:', error);
    next(error);
  }
};

// @desc    Get single note
// @route   GET /api/notes/:id
// @access  Private
const getNote = async (req, res, next) => {
  try {
    const note = await Note.findOne({
      _id: req.params.id,
      user: req.user._id
    }).populate('user', 'name email');

    if (!note) {
      return res.status(404).json({
        success: false,
        message: 'Note not found'
      });
    }

    res.status(200).json({
      success: true,
      note
    });

  } catch (error) {
    console.error('GetNote error:', error);

    if (error.name === 'CastError') {
      return res.status(404).json({
        success: false,
        message: 'Note not found'
      });
    }

    next(error);
  }
};

// @desc    Create new note
// @route   POST /api/notes
// @access  Private
const createNote = async (req, res, next) => {
  try {
    // Add user to req.body
    req.body.user = req.user._id;

    const note = await Note.create(req.body);

    // Populate user info
    await note.populate('user', 'name email');

    res.status(201).json({
      success: true,
      message: 'Note created successfully',
      note
    });

  } catch (error) {
    console.error('CreateNote error:', error);
    next(error);
  }
};

// @desc    Update note
// @route   PUT /api/notes/:id
// @access  Private
const updateNote = async (req, res, next) => {
  try {
    let note = await Note.findOne({
      _id: req.params.id,
      user: req.user._id
    });

    if (!note) {
      return res.status(404).json({
        success: false,
        message: 'Note not found'
      });
    }

    // Update note
    note = await Note.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true
      }
    ).populate('user', 'name email');

    res.status(200).json({
      success: true,
      message: 'Note updated successfully',
      note
    });

  } catch (error) {
    console.error('UpdateNote error:', error);

    if (error.name === 'CastError') {
      return res.status(404).json({
        success: false,
        message: 'Note not found'
      });
    }

    next(error);
  }
};

// @desc    Delete note
// @route   DELETE /api/notes/:id
// @access  Private
const deleteNote = async (req, res, next) => {
  try {
    const note = await Note.findOne({
      _id: req.params.id,
      user: req.user._id
    });

    if (!note) {
      return res.status(404).json({
        success: false,
        message: 'Note not found'
      });
    }

    await Note.findByIdAndDelete(req.params.id);

    res.status(200).json({
      success: true,
      message: 'Note deleted successfully'
    });

  } catch (error) {
    console.error('DeleteNote error:', error);

    if (error.name === 'CastError') {
      return res.status(404).json({
        success: false,
        message: 'Note not found'
      });
    }

    next(error);
  }
};

// @desc    Get user's tags
// @route   GET /api/notes/tags
// @access  Private
const getTags = async (req, res, next) => {
  try {
    const tags = await Note.getUserTags(req.user._id);

    res.status(200).json({
      success: true,
      count: tags.length,
      tags: tags.map(tag => ({
        name: tag._id,
        count: tag.count
      }))
    });

  } catch (error) {
    console.error('GetTags error:', error);
    next(error);
  }
};

// @desc    Bulk operations on notes
// @route   POST /api/notes/bulk
// @access  Private
const bulkOperations = async (req, res, next) => {
  try {
    const { operation, noteIds } = req.body;

    if (!operation || !noteIds || !Array.isArray(noteIds)) {
      return res.status(400).json({
        success: false,
        message: 'Operation and noteIds array are required'
      });
    }

    // Validate noteIds
    const validIds = noteIds.filter(id => mongoose.isValidObjectId(id));
    if (validIds.length !== noteIds.length) {
      return res.status(400).json({
        success: false,
        message: 'Invalid note IDs provided'
      });
    }

    let updateQuery = {};
    let message = '';

    switch (operation) {
      case 'archive':
        updateQuery = { isArchived: true };
        message = 'Notes archived successfully';
        break;
      case 'unarchive':
        updateQuery = { isArchived: false };
        message = 'Notes unarchived successfully';
        break;
      case 'pin':
        updateQuery = { isPinned: true };
        message = 'Notes pinned successfully';
        break;
      case 'unpin':
        updateQuery = { isPinned: false };
        message = 'Notes unpinned successfully';
        break;
      case 'delete':
        await Note.deleteMany({
          _id: { $in: validIds },
          user: req.user._id
        });
        return res.status(200).json({
          success: true,
          message: 'Notes deleted successfully'
        });
      default:
        return res.status(400).json({
          success: false,
          message: 'Invalid operation'
        });
    }

    const result = await Note.updateMany(
      {
        _id: { $in: validIds },
        user: req.user._id
      },
      updateQuery
    );

    res.status(200).json({
      success: true,
      message,
      modifiedCount: result.modifiedCount
    });

  } catch (error) {
    console.error('BulkOperations error:', error);
    next(error);
  }
};

// @desc    Search notes
// @route   GET /api/notes/search
// @access  Private
const searchNotes = async (req, res, next) => {
  try {
    const { q, limit = 10 } = req.query;

    if (!q || q.trim() === '') {
      return res.status(400).json({
        success: false,
        message: 'Search query is required'
      });
    }

    const notes = await Note.find({
      user: req.user._id,
      $or: [
        { title: { $regex: q, $options: 'i' } },
        { content: { $regex: q, $options: 'i' } },
        { tags: { $regex: q, $options: 'i' } }
      ]
    })
    .sort({ isPinned: -1, createdAt: -1 })
    .limit(parseInt(limit))
    .populate('user', 'name email');

    res.status(200).json({
      success: true,
      count: notes.length,
      notes
    });

  } catch (error) {
    console.error('SearchNotes error:', error);
    next(error);
  }
};

module.exports = {
  getNotes,
  getNote,
  createNote,
  updateNote,
  deleteNote,
  getTags,
  bulkOperations,
  searchNotes
};
