import React, { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { Menu, X, Search, Plus, Bell, Settings, LogOut, User, StickyNote } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { useNotes } from '../context/NotesContext'

const Header = ({ onToggleSidebar, sidebarOpen }) => {
  const navigate = useNavigate()
  const location = useLocation()
  const { user, logout } = useAuth()
  const { searchNotes } = useNotes()
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState([])
  const [showSearchResults, setShowSearchResults] = useState(false)
  const [showUserMenu, setShowUserMenu] = useState(false)

  const handleSearch = async (query) => {
    setSearchQuery(query)
    if (query.trim().length > 2) {
      try {
        const results = await searchNotes(query.trim(), 5)
        setSearchResults(results)
        setShowSearchResults(true)
      } catch (error) {
        console.error('Search error:', error)
        setSearchResults([])
      }
    } else {
      setSearchResults([])
      setShowSearchResults(false)
    }
  }

  const handleSearchResultClick = (noteId) => {
    navigate(`/notes/${noteId}/edit`)
    setSearchQuery('')
    setShowSearchResults(false)
  }

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  return (
    <header>
      {/* Your header markup */}
      <div>Header goes here.</div>
    </header>
  )
}

export default Header
