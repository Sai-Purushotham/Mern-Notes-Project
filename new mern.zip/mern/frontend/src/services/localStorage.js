const LocalStorage = {
  getItem: (key, defaultValue = null) => {
    try {
      const item = localStorage.getItem(key)
      return item ? JSON.parse(item) : defaultValue
    } catch (error) {
      return defaultValue
    }
  },
  setItem: (key, value) => {
    try {
      localStorage.setItem(key, JSON.stringify(value))
      return true
    } catch (error) {
      return false
    }
  },
  removeItem: (key) => {
    try {
      localStorage.removeItem(key)
      return true
    } catch (error) {
      return false
    }
  },
  clear: () => {
    try {
      localStorage.clear()
      return true
    } catch (error) {
      return false
    }
  }
}

export const StorageKeys = {
  TOKEN: 'token',
  USER: 'user',
  THEME: 'theme',
  NOTES_FILTERS: 'notes_filters',
  NOTES_VIEW: 'notes_view',
  SIDEBAR_COLLAPSED: 'sidebar_collapsed',
  RECENT_SEARCHES: 'recent_searches'
}

export const AppStorage = {
  getToken: () => LocalStorage.getItem(StorageKeys.TOKEN),
  setToken: token => LocalStorage.setItem(StorageKeys.TOKEN, token),
  removeToken: () => LocalStorage.removeItem(StorageKeys.TOKEN),

  getUser: () => LocalStorage.getItem(StorageKeys.USER),
  setUser: user => LocalStorage.setItem(StorageKeys.USER, user),
  removeUser: () => LocalStorage.removeItem(StorageKeys.USER),

  getTheme: () => LocalStorage.getItem(StorageKeys.THEME, 'light'),
  setTheme: theme => LocalStorage.setItem(StorageKeys.THEME, theme),

  getNotesFilters: () => LocalStorage.getItem(StorageKeys.NOTES_FILTERS, {}),
  setNotesFilters: filters => LocalStorage.setItem(StorageKeys.NOTES_FILTERS, filters),

  getNotesView: () => LocalStorage.getItem(StorageKeys.NOTES_VIEW, 'grid'),
  setNotesView: view => LocalStorage.setItem(StorageKeys.NOTES_VIEW, view),

  getSidebarCollapsed: () => LocalStorage.getItem(StorageKeys.SIDEBAR_COLLAPSED, false),
  setSidebarCollapsed: collapsed => LocalStorage.setItem(StorageKeys.SIDEBAR_COLLAPSED, collapsed),

  getRecentSearches: () => LocalStorage.getItem(StorageKeys.RECENT_SEARCHES, []),
  setRecentSearches: searches => LocalStorage.setItem(StorageKeys.RECENT_SEARCHES, searches),

  clearAppData: () => {
    Object.values(StorageKeys).forEach(key => LocalStorage.removeItem(key))
  }
}

export default LocalStorage
