import axios from 'axios'
import toast from 'react-hot-toast'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api',
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' }
})

api.interceptors.request.use(
  config => {
    const token = localStorage.getItem('token')
    if (token) config.headers.Authorization = `Bearer ${token}`
    return config
  },
  error => Promise.reject(error)
)

api.interceptors.response.use(
  response => response,
  error => {
    const { response } = error
    if (response?.status === 401) {
      localStorage.removeItem('token')
      toast.error('Session expired. Please log in again.')
      window.location.href = '/login'
    } else if (response?.status === 403) {
      toast.error('Access denied.')
    } else if (response?.status === 404) {
      toast.error('Resource not found.')
    } else if (response?.status >= 500) {
      toast.error('Server error. Please try again later.')
    }
    return Promise.reject(error)
  }
)

export const authAPI = {
  register: (userData) => api.post('/auth/register', userData),
  login: (credentials) => api.post('/auth/login', credentials),
  getMe: () => api.get('/auth/me'),
  updateProfile: (profileData) => api.put('/auth/profile', profileData),
  changePassword: (passwordData) => api.put('/auth/change-password', passwordData),
  deleteAccount: (data) => api.delete('/auth/account', { data }),
}

export const notesAPI = {
  getNotes: (params = {}) => {
    const searchParams = new URLSearchParams()
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        if (Array.isArray(value)) searchParams.append(key, value.join(','))
        else searchParams.append(key, value.toString())
      }
    })
    return api.get(`/notes?${searchParams.toString()}`)
  },
  getNote: (noteId) => api.get(`/notes/${noteId}`),
  createNote: (noteData) => api.post('/notes', noteData),
  updateNote: (noteId, noteData) => api.put(`/notes/${noteId}`, noteData),
  deleteNote: (noteId) => api.delete(`/notes/${noteId}`),
  getTags: () => api.get('/notes/tags'),
  bulkOperations: (data) => api.post('/notes/bulk', data),
  searchNotes: (params) => {
    const searchParams = new URLSearchParams(params)
    return api.get(`/notes/search?${searchParams.toString()}`)
  },
}

export default api
